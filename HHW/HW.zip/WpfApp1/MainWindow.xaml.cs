﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;


namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private List<Button> buttons = new List<Button>();
        private Random random = new Random();
        public MainWindow()
        {
            InitializeComponent();
           
        }

        private void CreateNewButton()
        {
            CreateNewButton(random);
        }

        private void CreateNewButton(Random random)
        {
            Button newButton = new Button();
            newButton.Content = "Button " + (buttons.Count + 1);
            newButton.Click += Button_Click;
           // newButton.Background= new SolidColorBrush(System.Drawing.Color.FromArgb(random.Next(0, 255), random.Next(0, 255)));
        btn_stck.Children.Insert(btn_stck.Children.Count - 1, newButton);
            buttons.Add(newButton);
            MessageBox.Show("Button List (Count: " + buttons.Count + ")");

        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button clickButton = (Button)sender;
            MessageBox.Show("Button: " + clickButton.Content + " Color:" + ((SolidColorBrush)clickButton.Background).Color.ToString());
        }
        private ContextMenu CreateContextMenu(Button button)
        {
            ContextMenu contextMenu = new ContextMenu();
            MenuItem deleteItem = new MenuItem();
            deleteItem.Header = "Delete";
            deleteItem.Click += (sender, e) => DeleteButton(button);
           
            contextMenu.Items.Add(deleteItem);
            return contextMenu;
        }


        private void DeleteButton(Button button)
        {
           btn_stck.Children.Remove(button);
            buttons.Remove(button);
            MessageBox.Show("Button List (Count: " + buttons.Count + ")");
        }
      
        private void Button_Click_1(object sender, MouseEventArgs er)
        {
            if (er is MouseButtonEventArgs mouseArgs)
            {
                if (mouseArgs.ChangedButton == MouseButton.Right)
                {
                    var btn = sender as Button;
                    btn_stck.Children.Remove(btn);
                    MessageBox.Show("Button List (Count: " + buttons.Count + ")");
                }
               
            }
        }




      
       
    }
}
